<html>
    <h1>BIENVENIDO</h1>
    <h3>Hola, <?php echo $_POST['nombre']?>, tu email es: <?php echo $_POST['email']?></h3> <!--$_POST['TIENE QUE PONER EL NOMBRE DEL FORMULARIO']-->
</html>
