    <footer>
        <p>Este es el pie de página</p>
    </footer>
</body>
</html>